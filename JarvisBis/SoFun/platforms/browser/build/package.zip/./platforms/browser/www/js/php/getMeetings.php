<?php

echo file_get_contents("meetings.json");
