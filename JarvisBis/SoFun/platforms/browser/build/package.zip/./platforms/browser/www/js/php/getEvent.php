<?php

echo file_get_contents("events.json");
